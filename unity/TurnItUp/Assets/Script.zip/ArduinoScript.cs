﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;
using System;

public class ArduinoScript : MonoBehaviour {
    SerialPort seri = new SerialPort("COM5", 9600);

    private void Start()
    {
        /*try
        {
            seri.Open();
            seri.DataReceived += DataReceivedHandler;
        } catch (Exception e) 
        {
            Debug.Log("Could not open serial port " + e.Message);
        }*/
        seri.Open();
        StartCoroutine(ReadDataFromSerialPort()); 
    }

    /*private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
    {
        SerialPort se = (SerialPort) sender;
        string[] values = se.ReadLine().Split(',');
        Debug.Log(values[0] + values[1] + values[2] + values[3]);
        PlayerPrefs.SetInt("red", Convert.ToInt32(values[0]));
        PlayerPrefs.SetInt("yellow", Convert.ToInt32(values[1]));
        PlayerPrefs.SetInt("green", Convert.ToInt32(values[2]));
        PlayerPrefs.SetInt("blue", Convert.ToInt32(values[3]));
    }*/

    IEnumerator ReadDataFromSerialPort()
    {
        while (true)
        {
            string[] values = seri.ReadLine().Split(',');
            PlayerPrefs.SetInt("red", Convert.ToInt32(values[0]));
            PlayerPrefs.SetInt("yellow", Convert.ToInt32(values[1]));
            PlayerPrefs.SetInt("green", Convert.ToInt32(values[2]));
            PlayerPrefs.SetInt("blue", Convert.ToInt32(values[3]));
            yield return new WaitForSeconds(.1f);//arduino delay
            //yield return true;
        }
    }

    void Update()
    {
    }

    private void OnApplicationQuit()
    {
        seri.Close();
    }
}
